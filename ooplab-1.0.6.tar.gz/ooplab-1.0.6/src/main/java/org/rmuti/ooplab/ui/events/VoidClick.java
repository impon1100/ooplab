package org.rmuti.ooplab.ui.events;

public abstract class VoidClick {
    public abstract void onClick();

}
