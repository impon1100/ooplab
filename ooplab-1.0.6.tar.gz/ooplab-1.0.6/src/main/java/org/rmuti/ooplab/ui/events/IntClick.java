package org.rmuti.ooplab.ui.events;

public abstract class IntClick {
    public abstract int getIntOnClick();
}
